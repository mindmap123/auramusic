"use client";

import LoginForm from "@/components/Auth/LoginForm";

export default function AdminLoginPage() {
    return <LoginForm />;
}
