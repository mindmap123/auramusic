import StoresContent from "./StoresContent";

export default function StoresPage() {
    return <StoresContent />;
}
